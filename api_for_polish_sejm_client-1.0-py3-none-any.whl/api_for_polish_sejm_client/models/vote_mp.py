import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.vote_value import VoteValue
from ..models.voting_kind import VotingKind
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.vote_mp_list_votes import VoteMPListVotes


T = TypeVar("T", bound="VoteMP")


@_attrs_define
class VoteMP:
    """a vote used in MP votings

    Attributes:
        voting_number (Union[Unset, int]): a voting number Example: 43.
        date (Union[Unset, datetime.datetime]): a voting date and time Example: 2022-09-29 15:56:30.
        kind (Union[Unset, VotingKind]):
        title (Union[Unset, str]): a voting title Example: Pkt. 27 Sprawozdanie Komisji o rządowym projekcie ustawy o
            zmianie ustawy - Prawo energetyczne oraz ustawy o odnawialnych źródłach energii (druki nr 2634, 2644 i 2644-A).
        description (Union[Unset, str]): description Example: a description of a voting.
        topic (Union[Unset, str]): a voting topic Example: głosowanie nad całością projektu.
        vote (Union[Unset, VoteValue]):
        list_votes (Union[Unset, VoteMPListVotes]): 'yes' votes on a list
    """

    voting_number: Union[Unset, int] = UNSET
    date: Union[Unset, datetime.datetime] = UNSET
    kind: Union[Unset, VotingKind] = UNSET
    title: Union[Unset, str] = UNSET
    description: Union[Unset, str] = UNSET
    topic: Union[Unset, str] = UNSET
    vote: Union[Unset, VoteValue] = UNSET
    list_votes: Union[Unset, "VoteMPListVotes"] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        voting_number = self.voting_number

        date: Union[Unset, str] = UNSET
        if not isinstance(self.date, Unset):
            date = self.date.isoformat()

        kind: Union[Unset, str] = UNSET
        if not isinstance(self.kind, Unset):
            kind = self.kind.value

        title = self.title

        description = self.description

        topic = self.topic

        vote: Union[Unset, str] = UNSET
        if not isinstance(self.vote, Unset):
            vote = self.vote.value

        list_votes: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.list_votes, Unset):
            list_votes = self.list_votes.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if voting_number is not UNSET:
            field_dict["votingNumber"] = voting_number
        if date is not UNSET:
            field_dict["date"] = date
        if kind is not UNSET:
            field_dict["kind"] = kind
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if topic is not UNSET:
            field_dict["topic"] = topic
        if vote is not UNSET:
            field_dict["vote"] = vote
        if list_votes is not UNSET:
            field_dict["listVotes"] = list_votes

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.vote_mp_list_votes import VoteMPListVotes

        d = src_dict.copy()
        voting_number = d.pop("votingNumber", UNSET)

        _date = d.pop("date", UNSET)
        date: Union[Unset, datetime.datetime]
        if isinstance(_date, Unset):
            date = UNSET
        else:
            date = isoparse(_date)

        _kind = d.pop("kind", UNSET)
        kind: Union[Unset, VotingKind]
        if isinstance(_kind, Unset):
            kind = UNSET
        else:
            kind = VotingKind(_kind)

        title = d.pop("title", UNSET)

        description = d.pop("description", UNSET)

        topic = d.pop("topic", UNSET)

        _vote = d.pop("vote", UNSET)
        vote: Union[Unset, VoteValue]
        if isinstance(_vote, Unset):
            vote = UNSET
        else:
            vote = VoteValue(_vote)

        _list_votes = d.pop("listVotes", UNSET)
        list_votes: Union[Unset, VoteMPListVotes]
        if isinstance(_list_votes, Unset):
            list_votes = UNSET
        else:
            list_votes = VoteMPListVotes.from_dict(_list_votes)

        vote_mp = cls(
            voting_number=voting_number,
            date=date,
            kind=kind,
            title=title,
            description=description,
            topic=topic,
            vote=vote,
            list_votes=list_votes,
        )

        vote_mp.additional_properties = d
        return vote_mp

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
