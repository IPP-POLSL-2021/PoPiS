import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.member_type import MemberType
from ..types import UNSET, Unset

T = TypeVar("T", bound="GroupMember")


@_attrs_define
class GroupMember:
    """Information about a member of a group

    Attributes:
        id (Union[Unset, str]): A number of the identity card of the MP Example: 6.
        name (Union[Unset, str]): Last and first name of the MP Example: Andzel Waldemar.
        club (Union[Unset, str]): Name of a club Example: PiS.
        senator (Union[Unset, bool]): A flag indicating that a member is not an MP, but a senate member
        type (Union[Unset, MemberType]):
        membership_start (Union[Unset, datetime.date]): A date when membership in this group started Example:
            2023-10-10.
        membership_end (Union[Unset, datetime.date]): A date when membership in this group ended Example: 2023-10-10.
        mandate_end (Union[Unset, datetime.date]): A date when mandate of MP expired Example: 2023-10-10.
    """

    id: Union[Unset, str] = UNSET
    name: Union[Unset, str] = UNSET
    club: Union[Unset, str] = UNSET
    senator: Union[Unset, bool] = UNSET
    type: Union[Unset, MemberType] = UNSET
    membership_start: Union[Unset, datetime.date] = UNSET
    membership_end: Union[Unset, datetime.date] = UNSET
    mandate_end: Union[Unset, datetime.date] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        id = self.id

        name = self.name

        club = self.club

        senator = self.senator

        type: Union[Unset, str] = UNSET
        if not isinstance(self.type, Unset):
            type = self.type.value

        membership_start: Union[Unset, str] = UNSET
        if not isinstance(self.membership_start, Unset):
            membership_start = self.membership_start.isoformat()

        membership_end: Union[Unset, str] = UNSET
        if not isinstance(self.membership_end, Unset):
            membership_end = self.membership_end.isoformat()

        mandate_end: Union[Unset, str] = UNSET
        if not isinstance(self.mandate_end, Unset):
            mandate_end = self.mandate_end.isoformat()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if club is not UNSET:
            field_dict["club"] = club
        if senator is not UNSET:
            field_dict["senator"] = senator
        if type is not UNSET:
            field_dict["type"] = type
        if membership_start is not UNSET:
            field_dict["membershipStart"] = membership_start
        if membership_end is not UNSET:
            field_dict["membershipEnd"] = membership_end
        if mandate_end is not UNSET:
            field_dict["mandateEnd"] = mandate_end

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        club = d.pop("club", UNSET)

        senator = d.pop("senator", UNSET)

        _type = d.pop("type", UNSET)
        type: Union[Unset, MemberType]
        if isinstance(_type, Unset):
            type = UNSET
        else:
            type = MemberType(_type)

        _membership_start = d.pop("membershipStart", UNSET)
        membership_start: Union[Unset, datetime.date]
        if isinstance(_membership_start, Unset):
            membership_start = UNSET
        else:
            membership_start = isoparse(_membership_start).date()

        _membership_end = d.pop("membershipEnd", UNSET)
        membership_end: Union[Unset, datetime.date]
        if isinstance(_membership_end, Unset):
            membership_end = UNSET
        else:
            membership_end = isoparse(_membership_end).date()

        _mandate_end = d.pop("mandateEnd", UNSET)
        mandate_end: Union[Unset, datetime.date]
        if isinstance(_mandate_end, Unset):
            mandate_end = UNSET
        else:
            mandate_end = isoparse(_mandate_end).date()

        group_member = cls(
            id=id,
            name=name,
            club=club,
            senator=senator,
            type=type,
            membership_start=membership_start,
            membership_end=membership_end,
            mandate_end=mandate_end,
        )

        group_member.additional_properties = d
        return group_member

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
