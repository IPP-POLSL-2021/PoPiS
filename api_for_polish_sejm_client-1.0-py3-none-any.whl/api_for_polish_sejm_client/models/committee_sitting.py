import datetime
from typing import Any, Dict, List, Type, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="CommitteeSitting")


@_attrs_define
class CommitteeSitting:
    """A committee sitting.

    Attributes:
        num (Union[Unset, int]): A sitting number Example: 1.
        date (Union[Unset, datetime.date]): A sitting date Example: 2023-11-21.
        closed (Union[Unset, bool]): A flag indicating that a meeting is closed
        remote (Union[Unset, bool]): A flag indicating that a meeting is a remote meeting
        video (Union[Unset, List[str]]): A list of links to video
        audio (Union[Unset, str]): A link to audio file
        city (Union[Unset, str]): A city where meeting took place
        joint_with (Union[Unset, List[str]]): A list of committees at joint meeting
        agenda (Union[Unset, str]): An agenda of a meeting
    """

    num: Union[Unset, int] = UNSET
    date: Union[Unset, datetime.date] = UNSET
    closed: Union[Unset, bool] = UNSET
    remote: Union[Unset, bool] = UNSET
    video: Union[Unset, List[str]] = UNSET
    audio: Union[Unset, str] = UNSET
    city: Union[Unset, str] = UNSET
    joint_with: Union[Unset, List[str]] = UNSET
    agenda: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        num = self.num

        date: Union[Unset, str] = UNSET
        if not isinstance(self.date, Unset):
            date = self.date.isoformat()

        closed = self.closed

        remote = self.remote

        video: Union[Unset, List[str]] = UNSET
        if not isinstance(self.video, Unset):
            video = self.video

        audio = self.audio

        city = self.city

        joint_with: Union[Unset, List[str]] = UNSET
        if not isinstance(self.joint_with, Unset):
            joint_with = self.joint_with

        agenda = self.agenda

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if num is not UNSET:
            field_dict["num"] = num
        if date is not UNSET:
            field_dict["date"] = date
        if closed is not UNSET:
            field_dict["closed"] = closed
        if remote is not UNSET:
            field_dict["remote"] = remote
        if video is not UNSET:
            field_dict["video"] = video
        if audio is not UNSET:
            field_dict["audio"] = audio
        if city is not UNSET:
            field_dict["city"] = city
        if joint_with is not UNSET:
            field_dict["jointWith"] = joint_with
        if agenda is not UNSET:
            field_dict["agenda"] = agenda

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        num = d.pop("num", UNSET)

        _date = d.pop("date", UNSET)
        date: Union[Unset, datetime.date]
        if isinstance(_date, Unset):
            date = UNSET
        else:
            date = isoparse(_date).date()

        closed = d.pop("closed", UNSET)

        remote = d.pop("remote", UNSET)

        video = cast(List[str], d.pop("video", UNSET))

        audio = d.pop("audio", UNSET)

        city = d.pop("city", UNSET)

        joint_with = cast(List[str], d.pop("jointWith", UNSET))

        agenda = d.pop("agenda", UNSET)

        committee_sitting = cls(
            num=num,
            date=date,
            closed=closed,
            remote=remote,
            video=video,
            audio=audio,
            city=city,
            joint_with=joint_with,
            agenda=agenda,
        )

        committee_sitting.additional_properties = d
        return committee_sitting

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
