from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.video import Video
from ...types import Response


def _get_kwargs(
    term: int,
    unid: str,
) -> Dict[str, Any]:
    _kwargs: Dict[str, Any] = {
        "method": "get",
        "url": f"/sejm/term{term}/videos/{unid}",
    }

    return _kwargs


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Video]:
    if response.status_code == HTTPStatus.OK:
        response_200 = Video.from_dict(response.json())

        return response_200
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Video]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    term: int,
    unid: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[Video]:
    """Returns a video transmission details

    Args:
        term (int):
        unid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Video]
    """

    kwargs = _get_kwargs(
        term=term,
        unid=unid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    term: int,
    unid: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[Video]:
    """Returns a video transmission details

    Args:
        term (int):
        unid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Video
    """

    return sync_detailed(
        term=term,
        unid=unid,
        client=client,
    ).parsed


async def asyncio_detailed(
    term: int,
    unid: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[Video]:
    """Returns a video transmission details

    Args:
        term (int):
        unid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Video]
    """

    kwargs = _get_kwargs(
        term=term,
        unid=unid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    term: int,
    unid: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[Video]:
    """Returns a video transmission details

    Args:
        term (int):
        unid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Video
    """

    return (
        await asyncio_detailed(
            term=term,
            unid=unid,
            client=client,
        )
    ).parsed
