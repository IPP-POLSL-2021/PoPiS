from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.group_details import GroupDetails
from ...types import Response


def _get_kwargs(
    term: int,
    id: int,
) -> Dict[str, Any]:
    _kwargs: Dict[str, Any] = {
        "method": "get",
        "url": f"/sejm/term{term}/bilateralGroups/{id}",
    }

    return _kwargs


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[GroupDetails]:
    if response.status_code == HTTPStatus.OK:
        response_200 = GroupDetails.from_dict(response.json())

        return response_200
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[GroupDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    term: int,
    id: int,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[GroupDetails]:
    """Returns a groups details

    Args:
        term (int):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GroupDetails]
    """

    kwargs = _get_kwargs(
        term=term,
        id=id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    term: int,
    id: int,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[GroupDetails]:
    """Returns a groups details

    Args:
        term (int):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GroupDetails
    """

    return sync_detailed(
        term=term,
        id=id,
        client=client,
    ).parsed


async def asyncio_detailed(
    term: int,
    id: int,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[GroupDetails]:
    """Returns a groups details

    Args:
        term (int):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GroupDetails]
    """

    kwargs = _get_kwargs(
        term=term,
        id=id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    term: int,
    id: int,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[GroupDetails]:
    """Returns a groups details

    Args:
        term (int):
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GroupDetails
    """

    return (
        await asyncio_detailed(
            term=term,
            id=id,
            client=client,
        )
    ).parsed
